export function formatMs(ms){
  const s = Math.floor(ms/1000);
  const h = Math.floor(s/3600);
  const m = Math.floor((s%3600)/60);
  const sec = s%60;
  const pad = (n)=>String(n).padStart(2,'0');
  return `${pad(h)}:${pad(m)}:${pad(sec)}`;
}
