# Classement — Front

Page de classement améliorée avec **recherche**, **tri** et limite (Top 50/100/200).

## Fichiers
- `public/leaderboard.html`
- `public/css/leaderboard.css`
- `public/js/timeFormat.js` (utilitaire)
- Requiert déjà `public/js/apiClient.js` (fourni à l'étape 4/6).

## Utilisation
1) Dépose ces fichiers dans `public/` de ton projet (ou fusionne).
2) Ouvre `leaderboard.html` pour tester. La page appelle `GET /api/leaderboard` côté back.
