<?php
namespace App\Service;

use App\Entity\GameSession;
use App\Entity\LeaderboardEntry;
use Doctrine\ORM\EntityManagerInterface;

class LeaderboardRebuilder
{
    public function __construct(private readonly EntityManagerInterface $em) {}

    /**
     * Reconstruit le classement à partir des sessions terminées.
     * Stratégie : 1 entrée par joueur = son meilleur temps.
     * @return array{players:int, entries:int}
     */
    public function rebuild(bool $dryRun = false): array
    {
        // Vider le tableau actuel
        if (!$dryRun) {
            $this->em->createQuery('DELETE FROM App\\Entity\\LeaderboardEntry e')->execute();
        }

        $qb = $this->em->createQueryBuilder();
        $qb->select('s')
            ->from(GameSession::class, 's')
            ->where($qb->expr()->orX(
                $qb->expr()->eq('s.status', ':finished'),
                $qb->expr()->isNotNull('s.finishedAt')
            ))
            ->setParameter('finished', 'finished');
        /** @var GameSession[] $sessions */
        $sessions = $qb->getQuery()->getResult();

        // Meilleur temps par joueur
        $best = []; // playerId => ['time' => int, 'completedAt' => \DateTimeInterface, 'session' => GameSession]
        foreach ($sessions as $s) {
            $player = $s->getPlayer();
            if (!$player) continue;
            $pid = (string)$player->getId();

            $time = (int)$s->getTotalTimeMs();
            // fallback: calcule depuis les dates si absent
            if ($time <= 0 && $s->getStartedAt() && $s->getFinishedAt()) {
                $time = max(0, $s->getFinishedAt()->getTimestamp() - $s->getStartedAt()->getTimestamp()) * 1000;
            }
            if ($time <= 0) continue;

            $completedAt = $s->getFinishedAt() ?? $s->getUpdatedAt() ?? $s->getStartedAt();
            if (!isset($best[$pid]) || $time < $best[$pid]['time']) {
                $best[$pid] = ['time' => $time, 'completedAt' => $completedAt, 'session' => $s];
            }
        }

        $count = 0;
        if (!$dryRun) {
            foreach ($best as $pid => $row) {
                $entry = new LeaderboardEntry($row['session']->getPlayer(), $row['time'], $row['completedAt']);
                $this->em->persist($entry);
                $count++;
            }
            $this->em->flush();
        } else {
            $count = count($best);
        }

        return ['players' => count($best), 'entries' => $count];
    }
}
