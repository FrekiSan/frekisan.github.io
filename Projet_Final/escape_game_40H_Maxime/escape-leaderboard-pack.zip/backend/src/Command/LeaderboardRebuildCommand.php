<?php
namespace App\Command;

use App\Service\LeaderboardRebuilder;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'app:leaderboard:rebuild',
    description: 'Recalcule le classement à partir des sessions terminées (meilleur temps par joueur).'
)]
class LeaderboardRebuildCommand extends Command
{
    public function __construct(private readonly LeaderboardRebuilder $rebuilder)
    {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addOption('dry-run', null, InputOption::VALUE_NONE, 'N\'écrit pas en base, affiche seulement le résultat.');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $dryRun = (bool) $input->getOption('dry-run');

        $io->title('Reconstruction du classement');
        if ($dryRun) $io->warning('Mode DRY-RUN — aucune écriture en base.');

        $stats = $this->rebuilder->rebuild($dryRun);
        $io->success(sprintf('OK — %d joueur(s), %d entrée(s) écrite(s).', $stats['players'], $stats['entries']));

        return Command::SUCCESS;
    }
}
