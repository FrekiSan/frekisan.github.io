# Classement — Backend

## Commande
Recalcule le classement (1 meilleure entrée par joueur) à partir des sessions terminées.

```bash
php bin/console app:leaderboard:rebuild
# dry run
php bin/console app:leaderboard:rebuild --dry-run
```

### Logique
- Vide `leaderboard_entries`.
- Prend toutes les `game_sessions` avec `status = finished` **ou** `finished_at` non nul.
- Calcule le temps: `total_time_ms` si présent, sinon `finished_at - started_at`.
- Conserve le **meilleur temps par joueur** et écrit une entrée par joueur.
