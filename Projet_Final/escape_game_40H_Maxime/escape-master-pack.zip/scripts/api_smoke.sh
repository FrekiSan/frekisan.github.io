#!/usr/bin/env bash
set -euo pipefail
BASE_URL="${1:-http://127.0.0.1:8000}"
echo "Create session:"
RESP=$(curl -sX POST "$BASE_URL/api/session" -H 'Content-Type: application/json' -d '{"nickname":"SmokeTest"}')
echo "$RESP"
SID=$(echo "$RESP" | sed -n 's/.*"session_id":"\([^"]*\)".*/\1/p')
TOK=$(echo "$RESP" | sed -n 's/.*"token":"\([^"]*\)".*/\1/p')
echo "Hints:"
curl -s "$BASE_URL/api/hints/ENIGME_01?session_id=$SID&token=$TOK" || true
echo
echo "Leaderboard:"
curl -s "$BASE_URL/api/leaderboard?limit=5"
echo
