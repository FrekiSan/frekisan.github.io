# 🧭 Escape Game — README Maître

Ce document est la vue d’ensemble **définitive** du projet (backend Symfony + front statique).

## Prérequis
PHP 8.2+, Composer, PostgreSQL 13+, Symfony CLI recommandée.  
Env: `APP_SESSION_SECRET`, `DATABASE_URL`, `APP_ENV`, `APP_DEBUG`.

## Installation
```bash
composer install
php bin/console doctrine:database:create
php bin/console doctrine:migrations:migrate -n
```
Importer les énigmes :
```bash
php bin/console app:import:enigmes --path=assets/lockees_converted --dry-run
php bin/console app:import:enigmes --path=assets/lockees_converted --replace
```
Vérifier :
```bash
php bin/console app:verify:integrity --assets-root=public
```

## API (résumé)
POST `/api/session`, POST `/api/attempt`, GET `/api/hints/{code}`, GET `/api/leaderboard`, GET `/api/story-videos`.

## Commandes
- `app:leaderboard:rebuild`
- `app:export:stats --format=csv --output=var/exports`
- `app:sessions:cleanup --hours=24`

Voir docs dans `docs/`.
