# API Reference — bref
Endpoints: /api/session, /api/attempt, /api/hints/{code}, /api/leaderboard, /api/story-videos.
Payloads conformes au README Maître et aux packs 3/6 et 6/6.
