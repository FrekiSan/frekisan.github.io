# MANIFEST SPEC
Voir exemple de manifest.json livré dans les packs précédents (code, title, type, order_index, is_active, base_image_path, success_image_path, story_video, solution).
