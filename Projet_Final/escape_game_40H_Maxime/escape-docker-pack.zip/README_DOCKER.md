# Docker & Compose — Escape Game

## Démarrage (dev)
```bash
docker compose up -d --build
# migrations si besoin
docker compose exec app php bin/console doctrine:migrations:migrate -n
```
Site: http://localhost:8080

## Commandes utiles
```bash
docker compose exec app php bin/console app:import:enigmes --path=assets/lockees_converted --replace
docker compose exec app php bin/console app:verify:integrity --assets-root=public
docker compose exec app php bin/console app:leaderboard:rebuild
```
