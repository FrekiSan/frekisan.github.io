<?php
namespace App\Service;

use App\Entity\AuditLog;
use Doctrine\ORM\EntityManagerInterface;

class AuditLogger
{
    public function __construct(private readonly EntityManagerInterface $em) {}

    public function log(string $action, array $payload = [], ?string $actor = 'system'): void
    {
        $log = new AuditLog($actor ?? 'system', $action, $payload);
        $this->em->persist($log);
        // On ne flush pas immédiatement pour laisser la transaction courante gérer la cohérence
    }
}
