<?php
namespace App\Service;

use App\Entity\Attempt;
use App\Entity\GameSession;
use App\Entity\Puzzle;
use Doctrine\ORM\EntityManagerInterface;

class StoryVideoService
{
    public function __construct(private readonly EntityManagerInterface $em) {}

    /**
     * Retourne les vidéos d'histoire déverrouillées pour une session donnée.
     * Règle: une vidéo est débloquée si la session a une tentative réussie sur le puzzle qui la référence.
     * @return array<int, array{title:string,youtube_id:?string,path:?string,autoredirect_next_ms:?int,puzzle_code:string}>
     */
    public function unlockedForSession(GameSession $session): array
    {
        $attemptRepo = $this->em->getRepository(Attempt::class);
        $successes = $attemptRepo->findBy(['session' => $session, 'isSuccess' => true]);

        $codes = [];
        foreach ($successes as $a) {
            $codes[] = $a->getPuzzle()->getCode();
        }
        $codes = array_unique($codes);
        if (!$codes) return [];

        $puzzles = $this->em->getRepository(Puzzle::class)->createQueryBuilder('p')
            ->leftJoin('p.storyVideo', 'v')->addSelect('v')
            ->where('p.code IN (:codes)')->setParameter('codes', $codes)
            ->getQuery()->getResult();

        $out = [];
        foreach ($puzzles as $p) {
            if (!$p->getStoryVideo()) continue;
            $v = $p->getStoryVideo();
            $out[] = [
                'title' => method_exists($v, 'getTitle') ? $v->getTitle() : 'Story',
                'youtube_id' => method_exists($v, 'getYoutubeId') ? $v->getYoutubeId() : null,
                'path' => method_exists($v, 'getPath') ? $v->getPath() : null,
                'autoredirect_next_ms' => method_exists($v, 'getAutoredirectNextMs') ? $v->getAutoredirectNextMs() : null,
                'puzzle_code' => $p->getCode(),
            ];
        }
        return $out;
    }
}
