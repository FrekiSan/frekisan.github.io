<?php
namespace App\Command;

use App\Entity\Attempt;
use App\Entity\Puzzle;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'app:export:stats',
    description: 'Exporte des statistiques (tentatives, taux de réussite, temps moyen) en CSV/JSON.'
)]
class ExportStatsCommand extends Command
{
    public function __construct(private readonly EntityManagerInterface $em) { parent::__construct(); }

    protected function configure(): void
    {
        $this
            ->addOption('format', null, InputOption::VALUE_REQUIRED, 'csv|json', 'csv')
            ->addOption('output', null, InputOption::VALUE_REQUIRED, 'Répertoire de sortie', 'public/exports');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $format = strtolower((string)$input->getOption('format'));
        $dir = (string)$input->getOption('output');
        if (!in_array($format, ['csv','json'], true)) {
            $io->error('Format invalide. Utilise csv ou json.');
            return Command::FAILURE;
        }
        if (!is_dir($dir)) mkdir($dir, 0777, true);

        $puzzles = $this->em->getRepository(Puzzle::class)->findBy([], ['orderIndex' => 'ASC']);
        $attemptRepo = $this->em->getRepository(Attempt::class);

        $rows = [];
        foreach ($puzzles as $p) {
            $attempts = $attemptRepo->findBy(['puzzle' => $p], ['attemptedAt' => 'ASC']);
            $total = count($attempts);
            $success = 0;
            $bySession = [];
            foreach ($attempts as $a) {
                $sid = (string)$a->getSession()->getId();
                if (!isset($bySession[$sid])) $bySession[$sid] = ['first' => $a, 'first_success' => null, 'count' => 0];
                $bySession[$sid]['count']++;
                if ($a->getIsSuccess() && $bySession[$sid]['first_success'] === null) {
                    $bySession[$sid]['first_success'] = $a;
                }
                if ($a->getIsSuccess()) $success++;
            }
            $succRate = $total > 0 ? round($success / $total * 100, 2) : 0.0;
            $avgAttemptsToSuccess = null;
            $avgTimeToSuccessMs = null;
            $sumAttempts = 0; $sumTime = 0; $n = 0;
            foreach ($bySession as $sid => $row) {
                if ($row['first_success'] !== null) {
                    $n++;
                    $sumAttempts += $row['count'];
                    $sumTime += max(0, $row['first_success']->getAttemptedAt()->getTimestamp() - $row['first']->getAttemptedAt()->getTimestamp()) * 1000;
                }
            }
            if ($n > 0) {
                $avgAttemptsToSuccess = round($sumAttempts / $n, 2);
                $avgTimeToSuccessMs = (int)round($sumTime / $n);
            }

            $rows[] = [
                'puzzle_code' => $p->getCode(),
                'title' => $p->getTitle(),
                'order_index' => $p->getOrderIndex(),
                'attempts_total' => $total,
                'success_total' => $success,
                'success_rate_percent' => $succRate,
                'avg_attempts_to_success' => $avgAttemptsToSuccess,
                'avg_time_to_success_ms' => $avgTimeToSuccessMs,
            ];
        }

        $ts = (new \DateTimeImmutable('now'))->format('Ymd_His');
        $file = sprintf('%s/stats_%s.%s', rtrim($dir, '/'), $ts, $format);
        if ($format === 'json') {
            file_put_contents($file, json_encode($rows, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
        } else {
            $fp = fopen($file, 'w');
            fputcsv($fp, array_keys($rows[0] ?? ['puzzle_code','title','order_index','attempts_total','success_total','success_rate_percent','avg_attempts_to_success','avg_time_to_success_ms']));
            foreach ($rows as $r) fputcsv($fp, $r);
            fclose($fp);
        }

        $io->success('Export écrit: '.$file);
        return Command::SUCCESS;
    }
}
