<?php
namespace App\Command;

use App\Entity\GameSession;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'app:sessions:cleanup',
    description: 'Clôture les sessions inactives depuis N heures (status=aborted, finished_at=now).'
)]
class SessionsCleanupCommand extends Command
{
    public function __construct(private readonly EntityManagerInterface $em) { parent::__construct(); }

    protected function configure(): void
    {
        $this
            ->addOption('hours', null, InputOption::VALUE_REQUIRED, 'Inactivité en heures', '12');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $hours = (int)$input->getOption('hours');
        $limit = (new \DateTimeImmutable('now'))->modify(sprintf('-%d hours', $hours));

        $qb = $this->em->createQueryBuilder();
        $qb->update(GameSession::class, 's')
            ->set('s.status', ':aborted')
            ->set('s.finishedAt', ':now')
            ->where('s.status = :running')
            ->andWhere('s.updatedAt < :limit')
            ->setParameters(['aborted' => 'aborted', 'running' => 'running', 'now' => new \DateTimeImmutable('now'), 'limit' => $limit]);
        $count = $qb->getQuery()->execute();

        $io->success(sprintf('%d session(s) clôturée(s) après %d h d\'inactivité.', $count, $hours));
        return Command::SUCCESS;
    }
}
