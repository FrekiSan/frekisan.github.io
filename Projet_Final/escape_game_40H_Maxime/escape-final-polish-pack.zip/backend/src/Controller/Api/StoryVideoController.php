<?php
namespace App\Controller\Api;

use App\Entity\GameSession;
use App\Service\StoryVideoService;
use App\Service\SessionSigner;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/api')]
class StoryVideoController
{
    public function __construct(
        private readonly EntityManagerInterface $em,
        private readonly StoryVideoService $videos,
        private readonly SessionSigner $signer
    ) {}

    #[Route('/story-videos', name: 'api_story_videos', methods: ['GET'])]
    public function list(Request $request): JsonResponse
    {
        $sessionId = $request->query->get('session_id');
        $token = $request->query->get('token');
        if (!$sessionId || !$token) {
            return new JsonResponse(['error' => 'session_id and token are required'], 400);
        }
        $validated = $this->signer->validate($token);
        if ($validated !== $sessionId) {
            return new JsonResponse(['error' => 'invalid token'], 401);
        }
        $session = $this->em->getRepository(GameSession::class)->find($sessionId);
        if (!$session) return new JsonResponse(['error' => 'session not found'], 404);

        $list = $this->videos->unlockedForSession($session);
        return new JsonResponse(['videos' => $list, 'count' => count($list)]);
    }
}
