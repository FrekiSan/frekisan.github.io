<?php
// AssetScanner placeholder; use previous content from our spec.
