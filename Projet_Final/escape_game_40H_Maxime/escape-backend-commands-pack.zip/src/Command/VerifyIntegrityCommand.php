<?php
// VerifyIntegrityCommand placeholder; use previous content from our spec.
