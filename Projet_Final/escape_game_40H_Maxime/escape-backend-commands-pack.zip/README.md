# Étape 2/6 — Commandes Symfony (squelette)
