# Étape 4/6 — Brancher les pages d'énigmes à l'API (Front JS)

Ce pack fournit des **modules ES** et des **exemples HTML** pour connecter tes pages aux endpoints : session, attempt, hints, leaderboard, et gérer **vidéo d'histoire + redirection**.

## Fichiers
- `public/js/apiClient.js` — client REST (session, attempt, hints, leaderboard)
- `public/js/timer.js` — timer global (lit `started_at` serveur depuis localStorage)
- `public/js/puzzleHandler.js` — logique générique d'une page énigme
- `public/js/hintsUI.js` — rendu des indices
- `public/js/videoStory.js` — overlay lecture vidéo (YouTube ou fichier)
- `public/js/sessionPage.js` — page d'accueil / démarrage
- `public/js/leaderboardUI.js` — affichage du classement
- `public/css/topbar.css` — styles minimaux (timer, overlay, hints)
- `public/enigme_template.html` — template d'une page énigme
- `public/index.html` — exemple d'accueil
- `public/classement.html` — exemple de classement
- `public/ending.html` — exemple de fin

## Intégration rapide
1) Copie `public/js` et `public/css` dans ton projet (ou fusionne).
2) Sur chaque page d'énigme, garde un **formulaire** avec `#answer-form` et `#answer`, puis importe :
   ```html
   <script type="module">
     import { mountGlobalTimer } from './js/timer.js';
     import { initPuzzlePage } from './js/puzzleHandler.js';
     mountGlobalTimer('#global-timer');
     const PUZZLE_CODE = 'ENIGME_08';
     initPuzzlePage({ puzzleCode: PUZZLE_CODE, secretSelector: '#secret-btn' });
   </script>
   ```
3) Si c'est l'énigme 14, affiche un bouton secret avec `id="secret-btn"` et `data-secret-link="videos.html"` (ou autre).

## Notes
- `attempt` renvoie `success`, `story_video` et `next_puzzle_code`. La vidéo est lue **avant** redirection.
- Le timer récupère `started_at` de `/api/session` et le réutilise sur toutes les pages.
- Les indices s'affichent à l'échec et peuvent être rafraîchis à volonté.

## Anti-triche (client)
- Latence de tentative (ms) envoyée au backend (télémétrie).
- Aucune logique de validation locale : tout passe par l'API.

Adapte les noms de fichiers aux conventions de tes pages (`enigme_01.html`, etc.).
