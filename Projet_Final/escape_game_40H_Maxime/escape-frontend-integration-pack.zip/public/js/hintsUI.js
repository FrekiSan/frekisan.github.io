// Fetch & render hints for a puzzle
import { storage, getHints } from './apiClient.js';

export async function renderHints(puzzleCode, containerSelector='#hints-container') {
  const session = storage.getSession();
  if (!session) return;
  const container = document.querySelector(containerSelector);
  if (!container) return;

  try {
    const { hints } = await getHints({ session_id: session.session_id, token: session.token, puzzle_code: puzzleCode });
    container.innerHTML = '';
    hints.forEach(h => {
      const item = document.createElement('div');
      item.className = 'eg-hint';
      item.innerHTML = `<div class="eg-hint-badge">Indice ${h.order}</div><div class="eg-hint-content">${h.content_html}</div>`;
      container.appendChild(item);
    });
  } catch (e) {
    console.warn('Hints error', e);
  }
}
