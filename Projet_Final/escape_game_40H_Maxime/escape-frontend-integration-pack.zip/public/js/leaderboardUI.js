// Render leaderboard table
import { getLeaderboard } from './apiClient.js';

export async function mountLeaderboard(tableSelector='#leaderboard-table', limit=100) {
  const table = document.querySelector(tableSelector);
  if (!table) return;
  try {
    const { entries } = await getLeaderboard(limit);
    const tbody = table.querySelector('tbody') || table.appendChild(document.createElement('tbody'));
    tbody.innerHTML = '';
    entries.forEach((e, idx) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${idx+1}</td><td>${e.player}</td><td>${formatMs(e.total_time_ms)}</td>`;
      tbody.appendChild(tr);
    });
  } catch (err) {
    console.error(err);
  }
}

function formatMs(ms) {
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const pad = (n)=> String(n).padStart(2,'0');
  return `${pad(h)}:${pad(m)}:${pad(sec)}`;
}
