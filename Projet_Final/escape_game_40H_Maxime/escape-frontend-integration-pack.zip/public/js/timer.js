// Global timer renderer (reads server start ISO from localStorage)
import { storage } from './apiClient.js';

let rafId = null;

function format(ms) {
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const pad = (n)=> String(n).padStart(2,'0');
  return `${pad(h)}:${pad(m)}:${pad(sec)}`;
}

export function mountGlobalTimer(elementSelector = '#global-timer') {
  const el = document.querySelector(elementSelector);
  if (!el) return;
  const startIso = storage.getTimerStart();
  if (!startIso) { el.textContent = '00:00:00'; return; }
  const t0 = new Date(startIso).getTime();

  function tick() {
    const now = Date.now();
    const ms = Math.max(0, now - t0);
    el.textContent = format(ms);
    rafId = requestAnimationFrame(tick);
  }
  cancelAnimationFrame(rafId);
  tick();
}
