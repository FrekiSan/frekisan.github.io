// ES module — API client for Escape Game
const API_BASE = '/api';

function jsonHeaders() {
  return { 'Content-Type': 'application/json' };
}

export const storage = {
  saveSession(data) { localStorage.setItem('eg_session', JSON.stringify(data)); },
  getSession() { try { return JSON.parse(localStorage.getItem('eg_session') || 'null'); } catch { return null; } },
  clearSession() { localStorage.removeItem('eg_session'); },
  saveTimerStart(iso) { localStorage.setItem('eg_timer_start_at', iso); },
  getTimerStart() { return localStorage.getItem('eg_timer_start_at'); },
};

export async function createOrResumeSession(nickname, email=null) {
  const res = await fetch(`${API_BASE}/session`, {
    method: 'POST',
    headers: jsonHeaders(),
    body: JSON.stringify({ nickname, email }),
  });
  if (!res.ok) throw new Error(`Session error: ${res.status}`);
  const data = await res.json();
  storage.saveSession({ session_id: data.session_id, token: data.token, nickname: data.player?.nickname || nickname });
  if (data.started_at) storage.saveTimerStart(data.started_at);
  return data;
}

export async function attempt({ session_id, token, puzzle_code, input_value, latency_ms=0 }) {
  const res = await fetch(`${API_BASE}/attempt`, {
    method: 'POST',
    headers: jsonHeaders(),
    body: JSON.stringify({ session_id, token, puzzle_code, input_value, latency_ms }),
  });
  if (!res.ok) throw new Error(`Attempt error: ${res.status}`);
  return res.json();
}

export async function getHints({ session_id, token, puzzle_code }) {
  const url = new URL(`${API_BASE}/hints/${encodeURIComponent(puzzle_code)}`, window.location.origin);
  url.searchParams.set('session_id', session_id);
  url.searchParams.set('token', token);
  const res = await fetch(url.toString());
  if (!res.ok) throw new Error(`Hints error: ${res.status}`);
  return res.json();
}

export async function getLeaderboard(limit=100) {
  const url = new URL(`${API_BASE}/leaderboard`, window.location.origin);
  url.searchParams.set('limit', String(limit));
  const res = await fetch(url.toString());
  if (!res.ok) throw new Error(`Leaderboard error: ${res.status}`);
  return res.json();
}
