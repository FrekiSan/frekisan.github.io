// Handle story video overlay (YouTube or file)
export function playStoryVideo({ youtube_id=null, path=null, title='Story', autoredirect_next_ms=null }) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'eg-video-overlay';
    overlay.innerHTML = `
      <div class="eg-video-modal">
        <button class="eg-video-close" aria-label="Fermer">&times;</button>
        <div class="eg-video-title">${title}</div>
        <div class="eg-video-container"></div>
      </div>`;
    document.body.appendChild(overlay);

    const container = overlay.querySelector('.eg-video-container');
    let player = null;

    if (youtube_id) {
      const iframe = document.createElement('iframe');
      iframe.setAttribute('allowfullscreen', 'true');
      iframe.setAttribute('frameborder', '0');
      iframe.src = `https://www.youtube.com/embed/${youtube_id}?autoplay=1`;
      iframe.style.width = '100%';
      iframe.style.height = '100%';
      player = iframe;
      container.appendChild(iframe);
    } else if (path) {
      const video = document.createElement('video');
      video.controls = true;
      video.autoplay = true;
      video.style.width = '100%';
      video.style.height = '100%';
      const src = document.createElement('source');
      src.src = path;
      video.appendChild(src);
      player = video;
      container.appendChild(video);
    } else {
      container.innerHTML = '<p>Aucune vidéo disponible.</p>';
    }

    const close = () => {
      overlay.remove();
      resolve();
    };
    overlay.querySelector('.eg-video-close').addEventListener('click', close);
    overlay.addEventListener('click', (e)=> { if (e.target === overlay) close(); });

    if (player && player.tagName === 'VIDEO') {
      player.addEventListener('ended', () => {
        if (autoredirect_next_ms == null) close();
      });
    }

    if (autoredirect_next_ms != null) {
      setTimeout(close, autoredirect_next_ms);
    }
  });
}
