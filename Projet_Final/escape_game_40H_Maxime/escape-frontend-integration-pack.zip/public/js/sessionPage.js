// Handle landing page: create/resume session and start game
import { storage, createOrResumeSession } from './apiClient.js';
import { mountGlobalTimer } from './timer.js';

export function initLanding({ formSelector='#start-form', nicknameInput='#nickname', emailInput='#email' }) {
  mountGlobalTimer('#global-timer');

  const form = document.querySelector(formSelector);
  if (!form) return;
  const pseudo = document.querySelector(nicknameInput);
  const email = document.querySelector(emailInput);

  form.addEventListener('submit', async (e)=> {
    e.preventDefault();
    const nickname = String(pseudo.value || '').trim();
    if (!nickname) { alert('Entre un pseudo.'); return; }
    try {
      const data = await createOrResumeSession(nickname, String(email?.value || '').trim() || null);
      // redirect to first puzzle (order 1), assumed ENIGME_01.html by convention
      window.location.href = 'enigme_01.html';
    } catch (err) {
      console.error(err);
      alert('Impossible de démarrer la partie.');
    }
  });
}
