// Generic puzzle page handler
import { storage, attempt } from './apiClient.js';
import { renderHints } from './hintsUI.js';
import { playStoryVideo } from './videoStory.js';

export function initPuzzlePage({ puzzleCode, answerInput='#answer', formSelector='#answer-form', hintsContainer='#hints-container', secretSelector=null, onBeforeSubmit=null }) {
  const form = document.querySelector(formSelector);
  const input = document.querySelector(answerInput);
  if (!form || !input) {
    console.warn('Form or input not found');
    return;
  }

  // Secret button (e.g., page 14)
  if (secretSelector) {
    const secret = document.querySelector(secretSelector);
    if (secret) {
      secret.addEventListener('click', () => {
        const href = secret.getAttribute('data-secret-link') || 'videos.html';
        window.location.href = href;
      });
    }
  }

  // latency capture
  let puzzleShownAt = performance.now();

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const session = storage.getSession();
    if (!session) {
      alert('Session absente. Retour à l’accueil.');
      window.location.href = 'index.html';
      return;
    }

    const value = String(input.value || '').trim();
    if (!value) return;

    try {
      if (typeof onBeforeSubmit === 'function') {
        const proceed = await onBeforeSubmit(value);
        if (proceed === false) return;
      }

      form.querySelector('[type="submit"]')?.setAttribute('disabled', 'true');

      const latency = Math.round(performance.now() - puzzleShownAt);
      const resp = await attempt({
        session_id: session.session_id,
        token: session.token,
        puzzle_code: puzzleCode,
        input_value: value,
        latency_ms: latency,
      });

      if (resp.success) {
        // show success UI
        document.body.classList.add('eg-success');
        const video = resp.story_video || null;
        if (video) {
          await playStoryVideo(video);
        }
        // redirect
        const next = resp.next_puzzle_code;
        if (next) {
          // try to infer next file name from code, fallback to index
          const target = (next + '.html').toLowerCase();
          window.location.href = target;
        } else {
          window.location.href = 'ending.html';
        }
      } else {
        // failure UI
        form.querySelector('[type="submit"]')?.removeAttribute('disabled');
        input.classList.add('eg-shake');
        setTimeout(()=>input.classList.remove('eg-shake'), 400);
        renderHints(puzzleCode, hintsContainer);
      }
    } catch (err) {
      console.error(err);
      alert('Erreur de communication avec le serveur.');
      form.querySelector('[type="submit"]')?.removeAttribute('disabled');
    }
  });

  // Preload hints (optional)
  renderHints(puzzleCode, hintsContainer);
}
