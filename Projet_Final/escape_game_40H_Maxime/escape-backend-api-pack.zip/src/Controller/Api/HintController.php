<?php
namespace App\Controller\Api;

use App\Entity\GameSession;
use App\Entity\Puzzle;
use App\Service\HintService;
use App\Service\SessionSigner;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/api')]
class HintController
{
    public function __construct(
        private readonly EntityManagerInterface $em,
        private readonly HintService $hints,
        private readonly SessionSigner $signer
    ) {}

    #[Route('/hints/{puzzle_code}', name: 'api_hints', methods: ['GET'])]
    public function hints(Request $request, string $puzzle_code): JsonResponse
    {
        $sessionId = $request->query->get('session_id');
        $token = $request->query->get('token');
        if (!$sessionId || !$token) {
            return new JsonResponse(['error' => 'session_id and token are required'], 400);
        }
        $validatedSession = $this->signer->validate($token);
        if ($validatedSession !== $sessionId) {
            return new JsonResponse(['error' => 'invalid token'], 401);
        }
        $session = $this->em->getRepository(GameSession::class)->find($sessionId);
        if (!$session) return new JsonResponse(['error' => 'session not found'], 404);

        $puzzle = $this->em->getRepository(Puzzle::class)->findOneBy(['code' => $puzzle_code]);
        if (!$puzzle) return new JsonResponse(['error' => 'puzzle not found'], 404);

        $list = $this->hints->unlockedHints($session, $puzzle);
        return new JsonResponse(['hints' => $list, 'count' => count($list)]);
    }
}
