<?php
namespace App\Controller\Api;

use App\Service\LeaderboardService;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/api')]
class LeaderboardController
{
    public function __construct(private readonly LeaderboardService $board) {}

    #[Route('/leaderboard', name: 'api_leaderboard', methods: ['GET'])]
    public function leaderboard(Request $request): JsonResponse
    {
        $limit = (int)($request->query->get('limit') ?? 100);
        return new JsonResponse(['entries' => $this->board->top($limit)]);
    }
}
