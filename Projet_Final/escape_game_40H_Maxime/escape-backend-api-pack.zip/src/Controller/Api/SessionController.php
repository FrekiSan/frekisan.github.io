<?php
namespace App\Controller\Api;

use App\Service\GameSessionService;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/api')]
class SessionController
{
    public function __construct(private readonly GameSessionService $sessions) {}

    #[Route('/session', name: 'api_session_create', methods: ['POST'])]
    public function create(Request $request): JsonResponse
    {
        $data = json_decode($request->getContent(), true) ?? [];
        $nickname = $data['nickname'] ?? null;
        $email = $data['email'] ?? null;
        if (!$nickname) {
            return new JsonResponse(['error' => 'nickname is required'], 400);
        }
        $result = $this->sessions->createOrResume($nickname, $email);
        return new JsonResponse([
            'session_id' => (string)$result['session']->getId(),
            'session_code' => $result['session']->getSessionCode(),
            'token' => $result['token'],
            'player' => [
                'nickname' => $result['player']->getNickname(),
                'email' => $result['player']->getEmail(),
            ],
            'started_at' => method_exists($result['session'], 'getStartedAt') ? $result['session']->getStartedAt()->format(DATE_ATOM) : null,
        ]);
    }
}
