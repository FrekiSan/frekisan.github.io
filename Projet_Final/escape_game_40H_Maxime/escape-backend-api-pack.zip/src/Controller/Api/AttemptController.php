<?php
namespace App\Controller\Api;

use App\Entity\GameSession;
use App\Entity\Puzzle;
use App\Entity\Solution;
use App\Entity\Attempt;
use App\Service\PuzzleValidationService;
use App\Service\SessionSigner;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/api')]
class AttemptController
{
    public function __construct(
        private readonly EntityManagerInterface $em,
        private readonly SessionSigner $signer,
        private readonly PuzzleValidationService $validator
    ) {}

    #[Route('/attempt', name: 'api_attempt', methods: ['POST'])]
    public function attempt(Request $request): JsonResponse
    {
        $data = json_decode($request->getContent(), true) ?? [];
        $sessionId = $data['session_id'] ?? null;
        $token = $data['token'] ?? null;
        $puzzleCode = $data['puzzle_code'] ?? null;
        $inputValue = $data['input_value'] ?? '';
        $latency = (int)($data['latency_ms'] ?? 0);

        if (!$sessionId || !$token || !$puzzleCode) {
            return new JsonResponse(['error' => 'session_id, token, puzzle_code are required'], 400);
        }
        $validatedSession = $this->signer->validate($token);
        if ($validatedSession !== $sessionId) {
            return new JsonResponse(['error' => 'invalid token'], 401);
        }

        $session = $this->em->getRepository(GameSession::class)->find($sessionId);
        if (!$session) return new JsonResponse(['error' => 'session not found'], 404);

        $puzzle = $this->em->getRepository(Puzzle::class)->findOneBy(['code' => $puzzleCode]);
        if (!$puzzle) return new JsonResponse(['error' => 'puzzle not found'], 404);

        $solution = $this->em->getRepository(Solution::class)->findOneBy(['puzzle' => $puzzle]);
        if (!$solution) return new JsonResponse(['error' => 'solution not found for puzzle'], 409);

        $isSuccess = $this->validator->isValid($inputValue, $solution->getAnswerHash(), $solution->getValidationRules());

        $attempt = new Attempt($session, $puzzle, $inputValue, $isSuccess, $latency);
        $this->em->persist($attempt);

        // TODO: si succès, mettre à jour currentPuzzleOrder / finishedAt si dernière énigme (nécessite des setters)
        $this->em->flush();

        $resp = ['success' => $isSuccess];

        if ($isSuccess) {
            $resp['story_video'] = null;
            if ($puzzle->getStoryVideo()) {
                $v = $puzzle->getStoryVideo();
                $resp['story_video'] = [
                    'title' => $v->getTitle(),
                    'youtube_id' => method_exists($v, 'getYoutubeId') ? $v->getYoutubeId() : null,
                    'path' => method_exists($v, 'getPath') ? $v->getPath() : null,
                    'autoredirect_next_ms' => method_exists($v, 'getAutoredirectNextMs') ? $v->getAutoredirectNextMs() : null,
                ];
            }
            if ($puzzle->getNextPuzzle()) {
                $resp['next_puzzle_code'] = $puzzle->getNextPuzzle()->getCode();
            } else {
                $resp['next_puzzle_code'] = null;
            }
        }

        return new JsonResponse($resp);
    }
}
