<?php
namespace App\Service;

class PuzzleValidationService
{
    /**
     * Valide l'entrée contre la solution hashée (SHA-256 du texte normalisé).
     * Règles supportées (validation_rules):
     *  - case_insensitive: bool
     *  - trim: bool (default true)
     *  - remove_spaces: bool
     *  - remove_accents: bool (approximatif)
     */
    public function isValid(string $input, string $answerHash, ?array $rules = null): bool
    {
        $normalized = $this->normalize($input, $rules ?? []);
        $hash = hash('sha256', $normalized);
        return hash_equals($answerHash, $hash);
    }

    public function normalize(string $value, array $rules): string
    {
        $v = $value;
        $trim = $rules['trim'] ?? true;
        if ($trim) $v = trim($v);
        if (!empty($rules['remove_spaces'])) $v = preg_replace('/\s+/', '', $v);
        if (!empty($rules['case_insensitive'])) $v = mb_strtolower($v, 'UTF-8');
        if (!empty($rules['remove_accents'])) $v = $this->removeAccents($v);
        return $v;
    }

    private function removeAccents(string $str): string
    {
        $translit = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $str);
        return $translit !== false ? $translit : $str;
    }
}
