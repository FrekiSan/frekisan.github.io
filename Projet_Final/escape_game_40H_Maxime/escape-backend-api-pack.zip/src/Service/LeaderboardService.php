<?php
namespace App\Service;

use App\Entity\LeaderboardEntry;
use Doctrine\ORM\EntityManagerInterface;

class LeaderboardService
{
    public function __construct(private readonly EntityManagerInterface $em) {}

    public function top(int $limit = 100): array
    {
        $repo = $this->em->getRepository(LeaderboardEntry::class);
        $entries = $repo->findBy([], ['totalTimeMs' => 'ASC'], max(1, min($limit, 500)));
        $out = [];
        foreach ($entries as $e) {
            $out[] = [
                'player' => $e->getPlayer()->getNickname(),
                'total_time_ms' => $e->getTotalTimeMs(),
                'completed_at' => $e->getCompletedAt()->format(DATE_ATOM),
            ];
        }
        return $out;
    }
}
