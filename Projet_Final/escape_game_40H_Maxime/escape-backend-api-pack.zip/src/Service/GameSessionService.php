<?php
namespace App\Service;

use App\Entity\Player;
use App\Entity\GameSession;
use Doctrine\ORM\EntityManagerInterface;

class GameSessionService
{
    public function __construct(
        private readonly EntityManagerInterface $em,
        private readonly SessionSigner $signer
    ) {}

    public function createOrResume(string $nickname, ?string $email = null): array
    {
        $playerRepo = $this->em->getRepository(Player::class);
        $player = $playerRepo->findOneBy(['nickname' => $nickname]);
        if (!$player) {
            $player = new Player();
            $player->setNickname($nickname);
            if ($email) $player->setEmail($email);
            $this->em->persist($player);
            $this->em->flush();
        }

        $sessionRepo = $this->em->getRepository(GameSession::class);
        $running = $sessionRepo->findOneBy(['player' => $player, 'status' => 'running'], ['startedAt' => 'DESC']);

        if (!$running) {
            $code = $this->generateSessionCode();
            $running = new GameSession($player, $code);
            // TODO: set status to 'running' if needed by a setter
            $this->em->persist($running);
            $this->em->flush();
        }

        $token = $this->signer->sign((string)$running->getId());
        return ['player' => $player, 'session' => $running, 'token' => $token];
    }

    private function generateSessionCode(): string
    {
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        do {
            $code = '';
            for ($i=0; $i<8; $i++) $code .= $alphabet[random_int(0, strlen($alphabet)-1)];
            $exists = $this->em->getRepository(GameSession::class)->findOneBy(['sessionCode' => $code]);
        } while ($exists !== null);
        return $code;
    }
}
