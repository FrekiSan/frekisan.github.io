<?php
namespace App\Service;

use App\Entity\Hint;
use App\Entity\Attempt;
use App\Entity\GameSession;
use App\Entity\Puzzle;
use Doctrine\ORM\EntityManagerInterface;

class HintService
{
    public function __construct(private readonly EntityManagerInterface $em) {}

    /**
     * Retourne les indices déverrouillés pour une session et un puzzle.
     * Règles : unlock_rule peut contenir after_seconds et/ou after_attempts.
     */
    public function unlockedHints(GameSession $session, Puzzle $puzzle): array
    {
        $hints = $this->em->getRepository(Hint::class)->findBy(['puzzle' => $puzzle], ['orderIndex' => 'ASC']);
        $attemptRepo = $this->em->getRepository(Attempt::class);
        $attempts = $attemptRepo->findBy(['session' => $session, 'puzzle' => $puzzle], ['attemptedAt' => 'ASC']);
        $attemptCount = count($attempts);

        // Temps écoulé depuis le début de la session (approx si getStartedAt() dispo)
        $elapsed = 0;
        if (method_exists($session, 'getStartedAt')) {
            $elapsed = (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->getTimestamp() - $session->getStartedAt()->getTimestamp();
        }

        $out = [];
        foreach ($hints as $hint) {
            $rule = $hint->getUnlockRule() ?? [];
            $okSec = isset($rule['after_seconds']) ? ($elapsed >= (int)$rule['after_seconds']) : false;
            $okAtt = isset($rule['after_attempts']) ? ($attemptCount >= (int)$rule['after_attempts']) : false;
            if ($okSec || $okAtt || empty($rule)) {
                $out[] = [
                    'order' => $hint->getOrderIndex(),
                    'content_html' => $hint->getContentHtml(),
                ];
            }
        }
        return $out;
    }
}
