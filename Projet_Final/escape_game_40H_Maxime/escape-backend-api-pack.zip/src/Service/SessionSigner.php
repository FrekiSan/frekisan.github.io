<?php
namespace App\Service;

class SessionSigner
{
    public function __construct(private readonly string $secret) {}

    public function sign(string $sessionId, int $ttlSeconds = 7200): string
    {
        $exp = time() + $ttlSeconds;
        $payload = $sessionId.'.'.$exp;
        $mac = hash_hmac('sha256', $payload, $this->secret, true);
        return rtrim(strtr(base64_encode($payload.'.'.base64_encode($mac)), '+/', '-_'), '=');
    }

    public function validate(string $token): ?string
    {
        $raw = base64_decode(strtr($token, '-_', '+/'));
        if ($raw === false) return null;
        $parts = explode('.', $raw);
        if (count($parts) !== 3) return null;
        [$sessionId, $exp, $macB64] = $parts;
        if (!ctype_digit($exp) || (int)$exp < time()) return null;
        $expected = hash_hmac('sha256', $sessionId.'.'.$exp, $this->secret, true);
        $mac = base64_decode($macB64);
        if (!hash_equals($expected, $mac)) return null;
        return $sessionId;
    }
}
