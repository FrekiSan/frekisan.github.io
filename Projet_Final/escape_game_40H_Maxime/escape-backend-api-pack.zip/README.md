# Étape 3/6 — API minces + Services de domaine

Ce pack fournit les **endpoints JSON** et les **services** associés.

## Endpoints
- `POST /api/session` — crée/reprend une session
- `POST /api/attempt` — envoie une tentative pour un puzzle
- `GET  /api/hints/{puzzle_code}?session_id=...&token=...` — récupère les indices déverrouillés
- `GET  /api/leaderboard?limit=100` — top des meilleurs temps

## Services
- `GameSessionService` — création/reprise de session + code session unique
- `PuzzleValidationService` — validation hashée (SHA-256) avec normalisation
- `HintService` — déverrouillage d’indices (temps/essais)
- `LeaderboardService` — liste des meilleurs temps
- `SessionSigner` — signature HMAC des tokens de session (remplaçable par JWT)

## Installation
1) Copie `src/Controller/Api` et `src/Service` dans ton projet.
2) Ajoute `config/packages/services.api.yaml` et `config/routes/api.yaml` (ou fusionne dans tes fichiers existants).
3) Dans `.env`, ajoute la clé :
   ```env
   APP_SESSION_SECRET=CHANGE_ME_SUPER_SECRET_KEY
   ```

## Exemple d’usage (curl)
### Créer/reprendre une session
```bash
curl -sX POST http://localhost:8000/api/session   -H 'Content-Type: application/json'   -d '{"nickname":"Freki","email":"freki@example.com"}'
```
Réponse :
```json
{
  "session_id": "uuid...",
  "session_code": "AB3D7K9P",
  "token": "base64urltoken...",
  "player": { "nickname": "Freki", "email": "freki@example.com" },
  "started_at": "2025-09-01T12:00:00+00:00"
}
```

### Tenter une réponse
```bash
curl -sX POST http://localhost:8000/api/attempt   -H 'Content-Type: application/json'   -d '{
    "session_id":"...",
    "token":"...",
    "puzzle_code":"ENIGME_08",
    "input_value":"AZERTY",
    "latency_ms": 1200
  }'
```

### Récupérer les indices
```bash
curl -s "http://localhost:8000/api/hints/ENIGME_08?session_id=...&token=..."
```

### Leaderboard
```bash
curl -s "http://localhost:8000/api/leaderboard?limit=50"
```

## Notes importantes
- La **tolérance Levenshtein** n’est pas compatible avec un stockage **hashé uniquement**. Si tu veux accepter des fautes proches, stocke **plusieurs variantes normalisées** (et donc plusieurs hash) dans `validation_rules` ou une table à part.
- Certaines méthodes (getters/setters) doivent exister sur tes entités (GameSession, StoryVideo, etc.). Complète-les si nécessaire.
- `SessionSigner` utilise HMAC (secret `.env`). Tu peux remplacer par un JWT (LexikJWT) si tu préfères.
