
# Escape Game — Backend Symfony (starter entités + migration)

Ce kit contient :
- `src/Entity/*.php` : entités Doctrine avec UUID (Symfony Uid) et attributs PHP 8
- `src/Repository/*.php` : repositories de base
- `migrations/Version_init.php` : migration initiale PostgreSQL

## Configuration requise
- Symfony 6+ et PHP 8.2+
- DoctrineBundle
- Symfony UID: composer require symfony/uid
- Base de données PostgreSQL (recommandé)

## Installation
1. Copier `src/Entity` et `src/Repository` dans votre projet.
2. Déclarer le type `uuid` si nécessaire (doctrine/dbal >= 3 gère déjà).  
3. Lancer la migration :
   ```bash
   php bin/console doctrine:migrations:migrate
   ```

## Notes
- Certains getters/setters sont abrégés pour la lisibilité : complétez selon vos besoins.
- Les champs JSON utilisent `json` (Doctrine) ; côté PostgreSQL ils seront stockés en `jsonb`.
- Les contraintes et index suivent le DICO fourni.
