<?php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use App\Repository\PlayerRepository;
use Symfony\Component\Uid\Uuid;
use Doctrine\DBAL\Types\Types;


#[ORM\Entity(repositoryClass: {repo}::class)]
#[ORM\Table(name: 'players')]
class Player
{{
    #[ORM\Id]
    #[ORM\Column(type: 'uuid')]
    private ?Uuid $id = null;

    #[ORM\Column(type: 'string', length: 32, unique: true)]
    private string $nickname;

    #[ORM\Column(type: 'string', length: 255, unique: true, nullable: true)]
    private ?string $email = null;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private ?string $avatarUrl = null;

    #[ORM\Column(type: 'boolean', options: ['default' => false])]
    private bool $consentGdpr = false;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private \DateTimeInterface $createdAt;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private \DateTimeInterface $updatedAt;

    public function __construct()
    {{
        $this->id = Uuid::v4();
        $now = new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
        $this->createdAt = $now;
        $this->updatedAt = $now;
    }}

    public function getId(): ?Uuid {{ return $this->id; }}
    public function getNickname(): string {{ return $this->nickname; }}
    public function setNickname(string $nickname): self {{ $this->nickname = $nickname; return $this; }}
    public function getEmail(): ?string {{ return $this->email; }}
    public function setEmail(?string $email): self {{ $this->email = $email; return $this; }}
    public function getAvatarUrl(): ?string {{ return $this->avatarUrl; }}
    public function setAvatarUrl(?string $avatarUrl): self {{ $this->avatarUrl = $avatarUrl; return $this; }}
    public function hasConsentGdpr(): bool {{ return $this->consentGdpr; }}
    public function setConsentGdpr(bool $consent): self {{ $this->consentGdpr = $consent; return $this; }}
    public function getCreatedAt(): \DateTimeInterface {{ return $this->createdAt; }}
    public function setCreatedAt(\DateTimeInterface $dt): self {{ $this->createdAt = $dt; return $this; }}
    public function getUpdatedAt(): \DateTimeInterface {{ return $this->updatedAt; }}
    public function setUpdatedAt(\DateTimeInterface $dt): self {{ $this->updatedAt = $dt; return $this; }}
}}
