<?php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use App\Repository\StoryVideoRepository;
use Symfony\Component\Uid\Uuid;
use Doctrine\DBAL\Types\Types;


#[ORM\Entity(repositoryClass: {repo}::class)]
#[ORM\Table(name: 'story_videos')]
class StoryVideo
{{
    #[ORM\Id]
    #[ORM\Column(type: 'uuid')]
    private ?Uuid $id = null;

    #[ORM\Column(type: 'string', length: 120)]
    private string $title;

    #[ORM\Column(type: 'string', length: 32, nullable: true)]
    private ?string $youtubeId = null;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private ?string $path = null;

    #[ORM\Column(type: 'boolean')]
    private bool $displayAfterSuccess = true;

    #[ORM\Column(type: 'integer', nullable: true)]
    private ?int $autoredirectNextMs = null;

    public function __construct(string $title)
    {{
        $this->id = Uuid::v4();
        $this->title = $title;
    }}
}}
