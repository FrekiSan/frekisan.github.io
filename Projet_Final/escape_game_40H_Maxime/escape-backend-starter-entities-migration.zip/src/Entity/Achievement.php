<?php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use App\Repository\AchievementRepository;
use Symfony\Component\Uid\Uuid;
use Doctrine\DBAL\Types\Types;


#[ORM\Entity(repositoryClass: {repo}::class)]
#[ORM\Table(name: 'achievements')]
class Achievement
{{
    #[ORM\Id]
    #[ORM\Column(type: 'uuid')]
    private ?Uuid $id = null;

    #[ORM\Column(type: 'string', length: 32, unique: true)]
    private string $code;

    #[ORM\Column(type: 'string', length: 120)]
    private string $label;

    #[ORM\Column(type: Types::JSON, nullable: true)]
    private ?array $criteria = null;

    public function __construct(string $code, string $label, ?array $criteria = null)
    {{
        $this->id = Uuid::v4();
        $this->code = $code;
        $this->label = $label;
        $this->criteria = $criteria;
    }}
}}
