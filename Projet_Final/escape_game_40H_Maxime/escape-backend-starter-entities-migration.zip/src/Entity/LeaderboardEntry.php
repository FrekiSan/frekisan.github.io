<?php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use App\Repository\LeaderboardEntryRepository;
use Symfony\Component\Uid\Uuid;
use Doctrine\DBAL\Types\Types;


use App\Entity\Player;

#[ORM\Entity(repositoryClass: {repo}::class)]
#[ORM\Table(name: 'leaderboard_entries')]
#[ORM\Index(columns: ['total_time_ms'])]
class LeaderboardEntry
{{
    #[ORM\Id]
    #[ORM\Column(type: 'uuid')]
    private ?Uuid $id = null;

    #[ORM\ManyToOne(targetEntity: Player::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Player $player;

    #[ORM\Column(type: 'bigint')]
    private int $totalTimeMs;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private \DateTimeInterface $completedAt;

    public function __construct(Player $player, int $totalTimeMs, \DateTimeInterface $completedAt)
    {{
        $this->id = Uuid::v4();
        $this->player = $player;
        $this->totalTimeMs = $totalTimeMs;
        $this->completedAt = $completedAt;
    }}
}}
