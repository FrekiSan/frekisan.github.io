<?php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use App\Repository\SessionAchievementRepository;
use Symfony\Component\Uid\Uuid;
use Doctrine\DBAL\Types\Types;


use App\Entity\GameSession;
use App\Entity\Achievement;

#[ORM\Entity(repositoryClass: {repo}::class)]
#[ORM\Table(name: 'session_achievements')]
class SessionAchievement
{{
    #[ORM\Id]
    #[ORM\ManyToOne(targetEntity: GameSession::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private GameSession $session;

    #[ORM\Id]
    #[ORM\ManyToOne(targetEntity: Achievement::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Achievement $achievement;
}}
