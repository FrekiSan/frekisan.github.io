<?php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use App\Repository\PuzzleAssetRepository;
use Symfony\Component\Uid\Uuid;
use Doctrine\DBAL\Types\Types;


use App\Entity\Puzzle;

#[ORM\Entity(repositoryClass: {repo}::class)]
#[ORM\Table(name: 'puzzle_assets')]
class PuzzleAsset
{{
    #[ORM\Id]
    #[ORM\Column(type: 'uuid')]
    private ?Uuid $id = null;

    #[ORM\ManyToOne(targetEntity: Puzzle::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Puzzle $puzzle;

    #[ORM\Column(type: 'string', length: 16)]
    private string $kind;

    #[ORM\Column(type: 'string', length: 255)]
    private string $path;

    #[ORM\Column(type: Types::JSON, nullable: true)]
    private ?array $metadata = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private \DateTimeInterface $createdAt;

    public function __construct(Puzzle $puzzle, string $kind, string $path, ?array $metadata = null)
    {{
        $this->id = Uuid::v4();
        $this->puzzle = $puzzle;
        $this->kind = $kind;
        $this->path = $path;
        $this->metadata = $metadata;
        $this->createdAt = new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
    }}
}}
