<?php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use App\Repository\SolutionRepository;
use Symfony\Component\Uid\Uuid;
use Doctrine\DBAL\Types\Types;


use App\Entity\Puzzle;

#[ORM\Entity(repositoryClass: {repo}::class)]
#[ORM\Table(name: 'solutions')]
class Solution
{{
    #[ORM\Id]
    #[ORM\Column(type: 'uuid')]
    private ?Uuid $id = null;

    #[ORM\OneToOne(inversedBy: 'solution', targetEntity: Puzzle::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Puzzle $puzzle;

    #[ORM\Column(type: 'string', length: 64)]
    private string $answerHash;

    #[ORM\Column(type: Types::JSON, nullable: true)]
    private ?array $hintStrategy = null;

    #[ORM\Column(type: Types::JSON, nullable: true)]
    private ?array $validationRules = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private \DateTimeInterface $createdAt;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private \DateTimeInterface $updatedAt;

    public function __construct(Puzzle $puzzle, string $answerHash)
    {{
        $this->id = Uuid::v4();
        $this->puzzle = $puzzle;
        $this->answerHash = $answerHash;
        $now = new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
        $this->createdAt = $now;
        $this->updatedAt = $now;
    }}
}}
