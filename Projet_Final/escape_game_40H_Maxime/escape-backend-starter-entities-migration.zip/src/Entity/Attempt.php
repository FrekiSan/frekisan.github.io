<?php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use App\Repository\AttemptRepository;
use Symfony\Component\Uid\Uuid;
use Doctrine\DBAL\Types\Types;


use App\Entity\GameSession;
use App\Entity\Puzzle;

#[ORM\Entity(repositoryClass: {repo}::class)]
#[ORM\Table(name: 'attempts')]
#[ORM\Index(columns: ['session_id','puzzle_id','attempted_at'])]
class Attempt
{{
    #[ORM\Id]
    #[ORM\Column(type: 'uuid')]
    private ?Uuid $id = null;

    #[ORM\ManyToOne(targetEntity: GameSession::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private GameSession $session;

    #[ORM\ManyToOne(targetEntity: Puzzle::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Puzzle $puzzle;

    #[ORM\Column(type: 'string', length: 255)]
    private string $inputValue;

    #[ORM\Column(type: 'boolean')]
    private bool $isSuccess = false;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private \DateTimeInterface $attemptedAt;

    #[ORM\Column(type: 'integer')]
    private int $latencyMs = 0;

    public function __construct(GameSession $session, Puzzle $puzzle, string $inputValue, bool $isSuccess, int $latencyMs)
    {{
        $this->id = Uuid::v4();
        $this->session = $session;
        $this->puzzle = $puzzle;
        $this->inputValue = $inputValue;
        $this->isSuccess = $isSuccess;
        $this->latencyMs = $latencyMs;
        $this->attemptedAt = new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
    }}
}}
