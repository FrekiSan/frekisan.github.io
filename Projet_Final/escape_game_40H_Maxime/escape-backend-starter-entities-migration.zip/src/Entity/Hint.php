<?php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use App\Repository\HintRepository;
use Symfony\Component\Uid\Uuid;
use Doctrine\DBAL\Types\Types;


use App\Entity\Puzzle;

#[ORM\Entity(repositoryClass: {repo}::class)]
#[ORM\Table(name: 'hints')]
class Hint
{{
    #[ORM\Id]
    #[ORM\Column(type: 'uuid')]
    private ?Uuid $id = null;

    #[ORM\ManyToOne(targetEntity: Puzzle::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Puzzle $puzzle;

    #[ORM\Column(type: 'integer')]
    private int $orderIndex;

    #[ORM\Column(type: Types::TEXT)]
    private string $contentHtml;

    #[ORM\Column(type: Types::JSON, nullable: true)]
    private ?array $unlockRule = null;

    public function __construct(Puzzle $puzzle, int $orderIndex, string $contentHtml, ?array $unlockRule = null)
    {{
        $this->id = Uuid::v4();
        $this->puzzle = $puzzle;
        $this->orderIndex = $orderIndex;
        $this->contentHtml = $contentHtml;
        $this->unlockRule = $unlockRule;
    }}
}}
