<?php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use App\Repository\PuzzleRepository;
use Symfony\Component\Uid\Uuid;
use Doctrine\DBAL\Types\Types;


use App\Entity\StoryVideo;

#[ORM\Entity(repositoryClass: {repo}::class)]
#[ORM\Table(name: 'puzzles')]
class Puzzle
{{
    #[ORM\Id]
    #[ORM\Column(type: 'uuid')]
    private ?Uuid $id = null;

    #[ORM\Column(type: 'string', length: 32, unique: true)]
    private string $code;

    #[ORM\Column(type: 'string', length: 120)]
    private string $title;

    #[ORM\Column(type: 'string', length: 32)]
    private string $type;

    #[ORM\Column(type: 'integer', unique: true)]
    private int $orderIndex;

    #[ORM\Column(type: 'boolean')]
    private bool $isActive = true;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private ?string $successImagePath = null;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private ?string $baseImagePath = null;

    #[ORM\ManyToOne(targetEntity: StoryVideo::class)]
    #[ORM\JoinColumn(nullable: true, onDelete: 'SET NULL')]
    private ?StoryVideo $storyVideo = null;

    #[ORM\ManyToOne(targetEntity: Puzzle::class)]
    #[ORM\JoinColumn(nullable: true, onDelete: 'SET NULL')]
    private ?Puzzle $nextPuzzle = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private \DateTimeInterface $createdAt;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private \DateTimeInterface $updatedAt;

    public function __construct(string $code, string $title, string $type, int $orderIndex)
    {{
        $this->id = Uuid::v4();
        $this->code = $code;
        $this->title = $title;
        $this->type = $type;
        $this->orderIndex = $orderIndex;
        $now = new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
        $this->createdAt = $now;
        $this->updatedAt = $now;
    }}
}}
