<?php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use App\Repository\GameSessionRepository;
use Symfony\Component\Uid\Uuid;
use Doctrine\DBAL\Types\Types;


use App\Entity\Player;

#[ORM\Entity(repositoryClass: {repo}::class)]
#[ORM\Table(name: 'game_sessions')]
class GameSession
{{
    #[ORM\Id]
    #[ORM\Column(type: 'uuid')]
    private ?Uuid $id = null;

    #[ORM\ManyToOne(targetEntity: Player::class)]
    #[ORM\JoinColumn(nullable: false, onDelete: 'CASCADE')]
    private Player $player;

    #[ORM\Column(type: 'string', length: 8, unique: true)]
    private string $sessionCode;

    #[ORM\Column(type: 'string', length: 16)]
    private string $status = 'running';

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private \DateTimeInterface $startedAt;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $finishedAt = null;

    #[ORM\Column(type: 'bigint', options: ['default' => 0])]
    private int $totalTimeMs = 0;

    #[ORM\Column(type: 'integer', options: ['default' => 1])]
    private int $currentPuzzleOrder = 1;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private \DateTimeInterface $createdAt;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private \DateTimeInterface $updatedAt;

    public function __construct(Player $player, string $sessionCode)
    {{
        $this->id = Uuid::v4();
        $this->player = $player;
        $this->sessionCode = $sessionCode;
        $now = new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
        $this->startedAt = $now;
        $this->createdAt = $now;
        $this->updatedAt = $now;
    }}

    // getters/setters omitted for brevity (add as needed)
}}
