<?php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use App\Repository\AuditLogRepository;
use Symfony\Component\Uid\Uuid;
use Doctrine\DBAL\Types\Types;


#[ORM\Entity(repositoryClass: {repo}::class)]
#[ORM\Table(name: 'audit_logs')]
#[ORM\Index(columns: ['occurred_at'])]
class AuditLog
{{
    #[ORM\Id]
    #[ORM\Column(type: 'uuid')]
    private ?Uuid $id = null;

    #[ORM\Column(type: 'string', length: 64)]
    private string $actor;

    #[ORM\Column(type: 'string', length: 64)]
    private string $action;

    #[ORM\Column(type: Types::JSON, nullable: true)]
    private ?array $payload = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private \DateTimeInterface $occurredAt;

    public function __construct(string $actor, string $action, ?array $payload = null)
    {{
        $this->id = Uuid::v4();
        $this->actor = $actor;
        $this->action = $action;
        $this->payload = $payload;
        $this->occurredAt = new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
    }}
}}
