<?php
declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20250901094857 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Initial schema for Escape Game (players, sessions, puzzles, assets, attempts, solutions, hints, videos, leaderboard, achievements, audit)';
    }

    public function up(Schema $schema): void
    {
        // This migration is tailored for PostgreSQL
        $this->addSql("CREATE TABLE players (id UUID NOT NULL, nickname VARCHAR(32) NOT NULL, email VARCHAR(255) DEFAULT NULL, avatar_url VARCHAR(255) DEFAULT NULL, consent_gdpr BOOLEAN DEFAULT FALSE NOT NULL, created_at TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL, updated_at TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL, PRIMARY KEY(id))");
        $this->addSql("CREATE UNIQUE INDEX UNIQ_PLAYERS_NICKNAME ON players (nickname)");
        $this->addSql("CREATE UNIQUE INDEX UNIQ_PLAYERS_EMAIL ON players (email)");

        $this->addSql("CREATE TABLE story_videos (id UUID NOT NULL, title VARCHAR(120) NOT NULL, youtube_id VARCHAR(32) DEFAULT NULL, path VARCHAR(255) DEFAULT NULL, display_after_success BOOLEAN NOT NULL, autoredirect_next_ms INT DEFAULT NULL, PRIMARY KEY(id))");

        $this->addSql("CREATE TABLE puzzles (id UUID NOT NULL, story_video_id UUID DEFAULT NULL, next_puzzle_id UUID DEFAULT NULL, code VARCHAR(32) NOT NULL, title VARCHAR(120) NOT NULL, type VARCHAR(32) NOT NULL, order_index INT NOT NULL, is_active BOOLEAN NOT NULL, success_image_path VARCHAR(255) DEFAULT NULL, base_image_path VARCHAR(255) DEFAULT NULL, created_at TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL, updated_at TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL, PRIMARY KEY(id))");
        $this->addSql("CREATE UNIQUE INDEX UNIQ_PUZZLES_CODE ON puzzles (code)");
        $this->addSql("CREATE UNIQUE INDEX UNIQ_PUZZLES_ORDER ON puzzles (order_index)");

        $this->addSql("CREATE TABLE puzzle_assets (id UUID NOT NULL, puzzle_id UUID NOT NULL, kind VARCHAR(16) NOT NULL, path VARCHAR(255) NOT NULL, metadata JSON DEFAULT NULL, created_at TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL, PRIMARY KEY(id))");
        $this->addSql("CREATE INDEX IDX_PUZZLE_ASSETS_PUZZLE ON puzzle_assets (puzzle_id)");

        $this->addSql("CREATE TABLE game_sessions (id UUID NOT NULL, player_id UUID NOT NULL, session_code CHAR(8) NOT NULL, status VARCHAR(16) NOT NULL, started_at TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL, finished_at TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL, total_time_ms BIGINT NOT NULL, current_puzzle_order INT NOT NULL, created_at TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL, updated_at TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL, PRIMARY KEY(id))");
        $this->addSql("CREATE UNIQUE INDEX UNIQ_GAME_SESSIONS_CODE ON game_sessions (session_code)");
        $this->addSql("CREATE INDEX IDX_GAME_SESSIONS_PLAYER ON game_sessions (player_id)");

        $this->addSql("CREATE TABLE attempts (id UUID NOT NULL, session_id UUID NOT NULL, puzzle_id UUID NOT NULL, input_value VARCHAR(255) NOT NULL, is_success BOOLEAN NOT NULL, attempted_at TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL, latency_ms INT NOT NULL, PRIMARY KEY(id))");
        $this->addSql("CREATE INDEX IDX_ATTEMPTS_SESSION ON attempts (session_id)");
        $this->addSql("CREATE INDEX IDX_ATTEMPTS_PUZZLE ON attempts (puzzle_id)");
        $this->addSql("CREATE INDEX IDX_ATTEMPTS_COMPOSITE ON attempts (session_id, puzzle_id, attempted_at)");

        $this->addSql("CREATE TABLE solutions (id UUID NOT NULL, puzzle_id UUID NOT NULL, answer_hash CHAR(64) NOT NULL, hint_strategy JSON DEFAULT NULL, validation_rules JSON DEFAULT NULL, created_at TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL, updated_at TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL, PRIMARY KEY(id))");
        $this->addSql("CREATE UNIQUE INDEX UNIQ_SOLUTIONS_PUZZLE ON solutions (puzzle_id)");

        $this->addSql("CREATE TABLE hints (id UUID NOT NULL, puzzle_id UUID NOT NULL, order_index INT NOT NULL, content_html TEXT NOT NULL, unlock_rule JSON DEFAULT NULL, PRIMARY KEY(id))");
        $this->addSql("CREATE INDEX IDX_HINTS_PUZZLE ON hints (puzzle_id)");

        $this->addSql("CREATE TABLE leaderboard_entries (id UUID NOT NULL, player_id UUID NOT NULL, total_time_ms BIGINT NOT NULL, completed_at TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL, PRIMARY KEY(id))");
        $this->addSql("CREATE INDEX IDX_LEADERBOARD_PLAYER ON leaderboard_entries (player_id)");
        $this->addSql("CREATE INDEX IDX_LEADERBOARD_TIME ON leaderboard_entries (total_time_ms)");

        $this->addSql("CREATE TABLE achievements (id UUID NOT NULL, code VARCHAR(32) NOT NULL, label VARCHAR(120) NOT NULL, criteria JSON DEFAULT NULL, PRIMARY KEY(id))");
        $this->addSql("CREATE UNIQUE INDEX UNIQ_ACHIEVEMENTS_CODE ON achievements (code)");

        $this->addSql("CREATE TABLE session_achievements (session_id UUID NOT NULL, achievement_id UUID NOT NULL, PRIMARY KEY(session_id, achievement_id))");

        $this->addSql("CREATE TABLE audit_logs (id UUID NOT NULL, actor VARCHAR(64) NOT NULL, action VARCHAR(64) NOT NULL, payload JSON DEFAULT NULL, occurred_at TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL, PRIMARY KEY(id))");
        $this->addSql("CREATE INDEX IDX_AUDIT_OCCURRED ON audit_logs (occurred_at)");

        // FKs
        $this->addSql("ALTER TABLE game_sessions ADD CONSTRAINT FK_SESSION_PLAYER FOREIGN KEY (player_id) REFERENCES players (id) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE");
        $this->addSql("ALTER TABLE puzzles ADD CONSTRAINT FK_PUZZLE_STORY_VIDEO FOREIGN KEY (story_video_id) REFERENCES story_videos (id) ON DELETE SET NULL NOT DEFERRABLE INITIALLY IMMEDIATE");
        $this->addSql("ALTER TABLE puzzles ADD CONSTRAINT FK_PUZZLE_NEXT FOREIGN KEY (next_puzzle_id) REFERENCES puzzles (id) ON DELETE SET NULL NOT DEFERRABLE INITIALLY IMMEDIATE");
        $this->addSql("ALTER TABLE puzzle_assets ADD CONSTRAINT FK_ASSET_PUZZLE FOREIGN KEY (puzzle_id) REFERENCES puzzles (id) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE");
        $this->addSql("ALTER TABLE attempts ADD CONSTRAINT FK_ATTEMPT_SESSION FOREIGN KEY (session_id) REFERENCES game_sessions (id) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE");
        $this->addSql("ALTER TABLE attempts ADD CONSTRAINT FK_ATTEMPT_PUZZLE FOREIGN KEY (puzzle_id) REFERENCES puzzles (id) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE");
        $this->addSql("ALTER TABLE solutions ADD CONSTRAINT FK_SOLUTION_PUZZLE FOREIGN KEY (puzzle_id) REFERENCES puzzles (id) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE");
        $this->addSql("ALTER TABLE hints ADD CONSTRAINT FK_HINT_PUZZLE FOREIGN KEY (puzzle_id) REFERENCES puzzles (id) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE");
        $this->addSql("ALTER TABLE leaderboard_entries ADD CONSTRAINT FK_LEADERBOARD_PLAYER FOREIGN KEY (player_id) REFERENCES players (id) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE");
        $this->addSql("ALTER TABLE session_achievements ADD CONSTRAINT FK_SESSACH_SESSION FOREIGN KEY (session_id) REFERENCES game_sessions (id) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE");
        $this->addSql("ALTER TABLE session_achievements ADD CONSTRAINT FK_SESSACH_ACHIEVEMENT FOREIGN KEY (achievement_id) REFERENCES achievements (id) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE");
    }

    public function down(Schema $schema): void
    {
        $this->addSql('DROP TABLE IF EXISTS session_achievements');
        $this->addSql('DROP TABLE IF EXISTS attempts');
        $this->addSql('DROP TABLE IF EXISTS solutions');
        $this->addSql('DROP TABLE IF EXISTS hints');
        $this->addSql('DROP TABLE IF EXISTS puzzle_assets');
        $this->addSql('DROP TABLE IF EXISTS puzzles');
        $this->addSql('DROP TABLE IF EXISTS story_videos');
        $this->addSql('DROP TABLE IF EXISTS leaderboard_entries');
        $this->addSql('DROP TABLE IF EXISTS achievements');
        $this->addSql('DROP TABLE IF EXISTS audit_logs');
        $this->addSql('DROP TABLE IF EXISTS game_sessions');
        $this->addSql('DROP TABLE IF EXISTS players');
    }
}
