Escape Game – La Bête du Gévaudan
==================================

Contenu de l'archive :
-----------------------
- Tous les fichiers HTML (Start, Intro, Enigmes 1 à 14, Fin, Classement, Crédits, Contact, Histoire)

- Dossier assets :
  - Images
  	- logo.png : logo utilisé sur toutes les pages
  	- favicon.ico : icône du site
  - CSS : 
	-style.css
	- responsive.css
  - JS :
  	- app.js: Logique principale de l'application
	- utilities.js : Fonctions utilitaires réutilisables
	- manager.js : Gère les états globaux (timer, stockage)
  	- classement.js : gère l'enregistrement et l'affichage du classement des joueurs

Bienvenue dans cette chasse a l'homme ou le temps presse! Deux personnes sont retenue captive au beau millieu de l'Auvergne, les rumeurs dans le coins disent que la bête du Gévaudan serait de retour...
Alors mythe ou réalite, à vous de le découvrir mais hatez vous car leurs vies est entre vos mains !

Bon Courage et Bon jeu !









































==================
Petit Tips:
Hé oui ! Si vous avez eu la curiosité de venir jusqu'ici, je vous offre ce petit indice à l'énigme 14. 
Si vous restez appuyé sur le logo, vous devriez trouver de l'aide pour résoudre l'énigme ;)